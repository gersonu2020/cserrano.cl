# bootstrap table
git clone https://github.com/wenzhixin/bootstrap-table.git
rm bootstrap-table/dist/extensions/export/tableExport.js*
cd bootstrap-table/dist/extensions/export/
wget http://rawgit.com/hhurz/tableExport.jquery.plugin/master/tableExport.js
